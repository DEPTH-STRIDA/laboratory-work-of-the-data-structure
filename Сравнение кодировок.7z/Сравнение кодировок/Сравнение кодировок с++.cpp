﻿#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

int main()
{   // Создаем вектор имен файлов
    vector<string> fileNames = { "engUTF-8.txt", "engUnicode.txt", "engASCII.txt","ruUTF-8.txt", "ruUnicode.txt", "ruASCII.txt" };

    // Создаем вектор массивов байт
    vector<vector<char>> byteArrays; 

    // Проходим по каждому имени файла в векторе
    for (const auto& fileName : fileNames) 
    { 
        // Открываем файл в двоичном режиме
        //ios::binary - флаг двоичного режима
        ifstream file(fileName, ios::binary); 

        // Получаем размер файла
        file.seekg(0, ios::end);             //Переместили курсор в конец файла
        const auto fileSize = file.tellg();  //Узнали расположение курсора = размер файла
        file.seekg(0, ios::beg);             //Вернули курсор в начало

        // Читаем содержимое файла в массив байт
        vector<char> bytes(fileSize);
        file.read(bytes.data(), fileSize);

        
        // Добавляем массив байт в вектор массивов байт
        byteArrays.push_back(bytes); 
    }
    
    //Создаем счетки для отделения RUS и ENG файлов
    int counter = 0;
    // Проходим по каждому массиву байт в векторе массивов байт
    for (const auto& byteArray : byteArrays) 
    {
        if (counter == 0){
            cout << "ENG: " << endl;
       } else if (counter == 3) {
           cout <<endl <<"RUS: " << endl;
       }
       counter++;

        // Проходим по каждому байту в массиве байт
        for (const auto& byte : byteArray) 
        {
            // Выводим значение байта в десятичном формате
            cout << static_cast<int>(byte) << " "; 
        }
        // Переходим на новую строку после вывода содержимого массива байт
        cout << endl; 
       
    }
    return 0; 
}